class Antenna():
    def __init__(self, position, radius):
        self.Position = position
        self.Radius = radius